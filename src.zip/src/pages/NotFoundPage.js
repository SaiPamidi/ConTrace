/* What react-router lands on if an invalid path is entered into the browser */

function NotFoundPage() {
    return (
        <div>
            <h2> 404 Not Found </h2>
        </div>
    );
}

export default NotFoundPage;